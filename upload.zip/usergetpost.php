<?php
  include 'db_info.php';

  $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
  $requestMethod = $_SERVER["REQUEST_METHOD"];

  switch ($requestMethod) {
    case 'GET':
      require_once 'getUserData.php';
      break;
    case 'POST':
      require_once 'upload.php';
      break;
    default:
      '메소드확인';
      break;
  }
?>
