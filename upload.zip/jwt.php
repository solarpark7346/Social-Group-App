<?php
include 'db_info.php';

class JWT {
  protected $alg;
  protected $secret_key;

  function __construct() {
    $this->alg = 'sha256';
    $this->secret_key = "secretkey";
  }

  function hashing(array $data): string
  {
    $header = json_encode(array(
      'alg' => $this->alg,
      'typ' => 'JWT'
    ));
    $payload = json_encode($data);
    $signature = hash($this->alg, $header . $payload . $this->secret_key);
    return base64_encode($header . '.' . $payload . '.' . $signature);
  }

  function dehashing($token) {
    $parted = explode('.', base64_decode($token));
    $signature = $parted[2];

    if (hash($this->alg, $parted[0] . $parted[1] . $this->secret_key) != $signature) {
      return "시그니쳐 오류";
    }

    $payload = json_decode($parted[1], true);
    if ($payload['exp'] < time()) {
      return "만료";
    }
    return json_decode($parted[1], true);
  }
}
?>
