<?php
include 'jwt.php';

$result = mysqli_query($con, "select * from members where email='$email'");
$row = mysqli_fetch_array($result);

$jwt = new JWT();
$email = $row["email"];
$email = base64_encode($email);

$token = $jwt->hashing(array(
  'exp' => time() + (360 * 30), // 만료기간
  'iat' => time(), // 생성일
  'id' => 10,
  'email' => $email
));

var_dump($token);

include 'tran_jwt.php';
?>
