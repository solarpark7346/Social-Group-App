<?php
  include 'db_info.php';

  $email = json_decode(file_get_contents("php://input"))->{"email"};
  $pw = json_decode(file_get_contents("php://input"))->{"pw"};

  $sql = "select * from members where email='$email'";
  $result = mysqli_query($con, $sql);
  $num_match = mysqli_num_rows($result);

  if(!$num_match){
    echo "이메일 틀림";
  }
  else{
    $row = mysqli_fetch_array($result);
    $ok_pw = $row["pw"];

    if($pw != $ok_pw) {
      http_response_code(400);
      echo "비번 틀림";
      exit;
    }
    else {
      //로그인 성공
      include 'make_jwt.php';
    }
  }
?>
