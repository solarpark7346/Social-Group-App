<?php
  include 'db_info.php';

    if(!empty($_FILES['file_attachment']['name']))
    {
        $target_dir = "uploads/";
        if (!file_exists($target_dir))
        {
        mkdir($target_dir, 0777);
        }
        $target_file =
        $target_dir . basename($_FILES["file_attachment"]["name"]);
        $imageFileType =
        strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        if (file_exists($target_file)) {
        echo json_encode(
            array(
            "status" => 0,
            "data" => array()
            ,"msg" => "Sorry, file already exists."
            )
        );
        die();
        }

        if ($_FILES["file_attachment"]["size"] > 50000000) {
        echo json_encode(
            array(
            "status" => 0,
            "data" => array(),
            "msg" => "Sorry, your file is too large."
            )
        );
        die();
        }
        if (
        move_uploaded_file(
            $_FILES["file_attachment"]["tmp_name"], $target_file
        )
        ) {
        echo json_encode(
            array(
            "status" => 1,
            "data" => array(),
            "msg" => "The file " .
                    basename( $_FILES["file_attachment"]["name"]) .
                    " has been uploaded."));
        } else {
        echo json_encode(
            array(
            "status" => 0,
            "data" => array(),
            "msg" => "Sorry, there was an error uploading your file."
            )
        );
        }
    }


        if(!empty($_FILES['file_attachment']['name'])) {
        $res        = array();
        $name       = 'file_attachment';
        $imagePath 	= 'assets/upload/file_attachment';
        $temp       = explode(".",$_FILES['file_attachment']['name']);
        $extension 	= end($temp);
        $filenew 	= str_replace(
                        $_FILES['file_attachment']['name'],
                        $name,
                        $_FILES['file_attachment']['name']) .
                        '_' . time() . '' . "." . $extension;
        $config['file_name']   = $filenew;
        $config['upload_path'] = $imagePath;
        $this->upload->initialize($config);
        $this->upload->set_allowed_types('*');
        $this->upload->set_filename($config['upload_path'],$filenew);
        if(!$this->upload->do_upload('file_attachment')) {
            $data = array('msg' => $this->upload->display_errors());
        } else {
            $data = $this->upload->data();
            if(!empty($data['file_name'])){
            $res['image_url'] = 'assets/upload/file_attachment/' .
            $data['file_name'];
            }
            if (!empty($res)) {
        echo json_encode(
                array(
                "status" => 1,
                "data" => array(),
                "msg" => "upload successfully",
                "base_url" => base_url(),
                "count" => "0"
                )
            );
            }else{
        echo json_encode(
                array(
                "status" => 1,
                "data" => array(),
                "msg" => "not found",
                "base_url" => base_url(),
                "count" => "0"
                )
            );
            }
        }
        }


?>
