<?php
  include 'db_info.php';
  $file = file_get_contents("php://input");
  $data = json_decode($file, true);

  date_default_timezone_set('Asia/Seoul');
  $since_day = date("Y-m-d");

  function temp_pw(){
    $leng = 8;
    $char = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $charleng = strlen($char);
    $ran = "";
    for($i=0; $i<$leng; $i++){
      $ran .= $char[rand(0, $charleng -1)];
    }
    return $ran;
  }

  foreach($data as $row) {
    mysqli_query($con,
    "insert into members (name, stu_num, dep, now_gp, pw, email, p_num, ar, bir, since_day)
    values (
      '".$row['name'].
      "', '".$row['stu_num'].
      "', '".$row['dep'].
      "', '".$row['now_gp'].
      "', '".temp_pw().
      "', '".$row['email'].
      "', '".$row['p_num'].
      "', '".$row['ar'].
      "', '".$row['bir'].
      "', '$since_day')");
  }

  mysqli_close($con);
?>
