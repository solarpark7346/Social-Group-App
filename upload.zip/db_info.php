<?php
  $con = mysqli_connect("localhost", "root", "1234", "reunion");
  header('Content-Type: application/json; charset=UTF-8');
  header("HTTP/1.1 200 OK");
  header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE");
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Headers: Content-Type');
?>
