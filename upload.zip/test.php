<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.15.5/xlsx.full.min.js"></script>

<input type="file" onchange="readExcel()">

<script>
function readExcel() {
    let input = event.target;
    let reader = new FileReader();
    reader.onload = function () {
        let data = reader.result;
        let workBook = XLSX.read(data, { type: 'binary' });
        workBook.SheetNames.forEach(function (sheetName) {
            console.log('SheetName: ' + sheetName);
            let rows = XLSX.utils.sheet_to_json(workBook.Sheets[sheetName]);
            console.log(JSON.stringify(rows));
            var obj_s = JSON.stringify(rows, null, "\t");
            var dataUri = "data:application/json;charset=utf-8,"+ encodeURIComponent(obj_s);
            var link = document.getElementById("link");
            link.setAttribute("href", dataUri);
        })
    };
    reader.readAsBinaryString(input.files[0]);
}
</script>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <a href="#" id="link" download="userdata.json">다운로드</a>

    <img src="http://192.168.0.108/img/person.png">
  </body>
</html>
