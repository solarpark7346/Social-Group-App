<?php
  $sql = "select * from members";
  $result = mysqli_query($con, $sql);
  $total = mysqli_num_rows($result);
  for($i=0; $i<$total; $i++){
    mysqli_data_seek($result, $i);
    $result_model = $result->fetch_array();
    $data[] = array(
      'num'=>$result_model['num'],
      'name'=>$result_model['name'],
      'stu_num'=>$result_model['stu_num'],
      'dep'=>$result_model['dep'],
      'now_gp'=>$result_model['now_gp'],
      'pw'=>$result_model['pw'],
      'email'=>$result_model['email'],
      'p_num'=>$result_model['p_num'],
      'ar'=>$result_model['ar'],
      'bir'=>$result_model['bir']
    );
  }
  echo json_encode($data);

  mysqli_close($con);
?>
